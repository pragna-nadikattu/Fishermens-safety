# Fishermens-safety
Developed GPS wearables for fishermen's safety using Arduino. Implemented features include real-time location tracking, man overboard detection, boat tilt alerts, emergency signaling, and distress signal transmission via LoRa. Enhanced safety at sea by providing continuous monitoring and early warnings.
